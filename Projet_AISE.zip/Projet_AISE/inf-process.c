#define _WIN32_WINNT 0x0501
 
#include <stdio.h>
#include <string.h>

//#include <psapi.h>
 
void listProcesses_classic(void) {
	DWORD pids[1024];
	DWORD i,rc;
 
	EnumProcesses(pids,sizeof(pids),&rc);
	printf("Number of entries: %lu\n",rc/sizeof(pids[0]));
	for(i=0;i<rc/sizeof(pids[0]);i++) {
		HANDLE hdl;
		printf("%4u: pid=%4u ",i,pids[i]);
		hdl=OpenProcess(READ_CONTROL|PROCESS_QUERY_INFORMATION,0,pids[i]);
		if(hdl==NULL)
			printf("- handle error %u\n",GetLastError());
		else {
			char buffer[MAX_PATH];
			if(GetProcessImageFileName(hdl,buffer,sizeof(buffer))==0)
				printf("- GetProcessImageFilename() error %u\n",GetLastError());
			else {
				char *progname;
				progname=strrchr(buffer,'\\');
				if(progname==NULL)
					progname=buffer;
				else
					progname++;
				printf("- %s\n",progname);
			}
			CloseHandle(hdl);
		}
	}
	puts("");
}
 

int main(void) {
	listProcesses_classic();
	
 
	return(0);
}
